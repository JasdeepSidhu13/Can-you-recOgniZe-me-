var app = require("express")();
var bodyParser = require("body-parser");
var serveStatic = require('serve-static')

console.clear();

app.use(bodyParser.urlencoded({extended: true}));
app.set("view engine", "ejs");

// Imports the Google Cloud client library
const vision = require('@google-cloud/vision');

// Creates a client
const client = new vision.ImageAnnotatorClient();

app.get("/", function(req, res){
	res.render("app1");
});


var name, image;

app.post("/show", function(req, res){
	
	 name = req.body.avatar;
	 image = name;
	 console.log(image);


client
  .labelDetection(image)
  .then(results => {
    const labels = results[0].labelAnnotations;
var i = 0;
    console.log('Labels:');
   	var features = [];
    labels.forEach(function(label){
    	features.push(label.description);
    	console.log(features[i++]);
    });


    if(i<=0)
    	res.render("app1");
    else
    res.render("show", {features:features, image: image});
  })
  .catch(err => {
    console.error('ERROR:', err);
  });

});


app.listen(3000, function(){
	console.log("The Server Has Started");
});  